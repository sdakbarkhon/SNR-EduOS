import { motion, AnimatePresence } from 'motion/react';
import { X, Download, UploadCloud } from 'lucide-react';
import { Task } from '../data/tasks';
import { GlassCard } from './GlassCard';
import { cn } from '../lib/utils';
import { FormEvent } from 'react';

interface TaskModalProps {
  task: Task | null;
  onClose: () => void;
}

export function TaskModal({ task, onClose }: TaskModalProps) {
  if (!task) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    // Simulate submission
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/20 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <GlassCard className="p-0 overflow-hidden bg-white/80">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/40">
              <div className="flex items-center gap-4">
                <div className={cn("w-12 h-12 rounded-[14px] flex items-center justify-center", task.iconColorClass)}>
                  <task.icon size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-800">{task.subject}</h2>
                  <p className="text-sm font-medium text-slate-500">{task.title}</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
              
              {/* Deadline & Status Row */}
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-2 text-sm font-medium">
                   <span className="text-slate-500">Срок:</span>
                   <span className={cn(
                     task.deadlineUrgency === 'high' ? 'text-rose-500' :
                     task.deadlineUrgency === 'medium' ? 'text-amber-500' : 'text-emerald-500'
                   )}>
                     {task.deadline}
                   </span>
                 </div>
                 
                 {task.status === 'done' && (
                   <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
                     Выполнено
                   </span>
                 )}
              </div>

              {/* Description */}
              <div className="mb-8">
                <h3 className="text-sm font-semibold text-slate-800 mb-2 uppercase tracking-wide">Задание от преподавателя</h3>
                <p className="text-slate-600 leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-white/50">
                  {task.description}
                </p>
              </div>

              {/* Graded State View */}
              {task.status === 'done' && task.grade && (
                <div className="mb-8 bg-gradient-to-br from-emerald-50 to-teal-50 p-6 rounded-[20px] border border-emerald-100 shadow-sm">
                   <div className="flex justify-between items-start mb-4">
                      <div>
                         <h3 className="text-emerald-800 font-bold mb-1">Оценка</h3>
                         <span className="text-3xl font-black text-emerald-600 drop-shadow-sm">{task.grade}</span>
                      </div>
                      <span className="text-xs font-medium text-emerald-600/70 bg-emerald-100/50 px-2 py-1 rounded-md">{task.checkDate}</span>
                   </div>
                   {task.teacherComment && (
                     <div className="mt-4 pt-4 border-t border-emerald-200/60">
                        <p className="text-sm text-emerald-800 font-medium whitespace-pre-wrap">«{task.teacherComment}»</p>
                     </div>
                   )}
                </div>
              )}

              {/* Attachments */}
              {task.attachments && task.attachments.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-sm font-semibold text-slate-800 mb-3 uppercase tracking-wide">Материалы</h3>
                  <div className="flex flex-col gap-2">
                    {task.attachments.map((fileName, idx) => (
                      <button key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl hover:border-blue-200 hover:bg-blue-50 transition-colors group">
                        <span className="text-sm font-medium text-slate-700 group-hover:text-blue-700">{fileName}</span>
                        <Download size={16} className="text-slate-400 group-hover:text-blue-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Submission Form (Only for active UI) */}
              {task.status !== 'done' && (
                <form onSubmit={handleSubmit} className="border-t border-slate-100 pt-6">
                  <h3 className="text-sm font-semibold text-slate-800 mb-3 uppercase tracking-wide">Ваше решение</h3>
                  
                  <textarea 
                    rows={4}
                    placeholder="Напишите ответ или комментарий к заданию..."
                    className="w-full bg-white border border-slate-200 rounded-xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all mb-4 resize-none"
                  />

                  <div className="w-full border-2 border-dashed border-slate-200 rounded-xl p-8 mb-6 flex flex-col items-center justify-center text-center bg-slate-50/50 hover:bg-slate-50 hover:border-blue-300 transition-colors cursor-pointer">
                    <div className="w-10 h-10 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mb-3">
                      <UploadCloud size={20} />
                    </div>
                    <span className="text-sm font-medium text-slate-700 mb-1">Перетащите файлы сюда</span>
                    <span className="text-xs text-slate-500">или нажмите для выбора (до 50 МБ)</span>
                  </div>

                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-blue-500/30 transition-all active:scale-[0.98]">
                    Сдать задание
                  </button>
                </form>
              )}
            </div>
          </GlassCard>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
