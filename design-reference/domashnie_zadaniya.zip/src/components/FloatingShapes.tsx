import { motion } from "motion/react";

export function FloatingShapes() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#e0f2fe] via-[#f0f9ff] to-[#f5f3ff]" />
      
      {/* Shape 1: Blur blue circle */}
      <motion.div
        animate={{
          y: [0, -30, 0],
          x: [0, 20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[10%] left-[10%] w-96 h-96 bg-blue-400/20 rounded-full blur-[80px]"
      />

      {/* Shape 2: Blur purple circle */}
      <motion.div
        animate={{
          y: [0, 40, 0],
          x: [0, -20, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1
        }}
        className="absolute bottom-[20%] right-[15%] w-[30rem] h-[30rem] bg-indigo-400/20 rounded-full blur-[100px]"
      />

      {/* Shape 3: Geometric floating shape right */}
      <motion.div
        animate={{
          rotate: [0, 10, -5, 0],
          y: [0, -20, 0]
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[30%] right-[5%] w-64 h-64 bg-gradient-to-tr from-cyan-300/30 to-blue-500/30 rounded-[40px] rotate-12 blur-[60px]"
      />
      
      {/* Shape 4: Soft cyan glowing orb */}
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.5, 0.8, 0.5]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[60%] left-[30%] w-48 h-48 bg-cyan-300/20 rounded-full blur-[50px]"
      />
    </div>
  );
}
