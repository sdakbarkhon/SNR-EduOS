import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { GlassCard } from './GlassCard';
import { mockTasks } from '../data/tasks';

export function StatsCard() {
  const activeCount = mockTasks.filter(t => t.status === 'active').length;
  const reviewCount = mockTasks.filter(t => t.status === 'review').length;
  const doneCount = mockTasks.filter(t => t.status === 'done').length;
  const overdueCount = mockTasks.filter(t => t.status === 'overdue').length;
  
  const total = activeCount + reviewCount + doneCount + overdueCount;

  const data = [
    { name: 'Активные', value: activeCount, color: '#3b82f6' }, // blue-500
    { name: 'Выполненные', value: doneCount, color: '#0ea5e9' }, // sky-500
    { name: 'Просроченные', value: overdueCount, color: '#ec4899' }, // pink-500
    { name: 'На проверке', value: reviewCount, color: '#fbbf24' }, // amber-400
  ].filter(item => item.value > 0);

  return (
    <GlassCard className="p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-6">Статистика</h3>
      
      <div className="flex items-center gap-6">
        {/* Chart */}
        <div className="relative w-40 h-40">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={70}
                paddingAngle={4}
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-[10px] text-slate-500 font-medium">Всего заданий</span>
            <span className="text-2xl font-bold text-slate-800">{total}</span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-col gap-3 flex-1">
          {data.map((item) => (
            <div key={item.name} className="flex flex-row items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-slate-600">{item.name}</span>
              </div>
              <span className="font-semibold text-slate-800">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </GlassCard>
  );
}
