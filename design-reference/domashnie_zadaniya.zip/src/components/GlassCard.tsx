import React from 'react';
import { cn } from '../lib/utils';

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  hoverEffect?: boolean;
}

export function GlassCard({ children, className, onClick, hoverEffect = false, ...props }: GlassCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "bg-white/70 backdrop-blur-2xl border-[1.5px] border-white/80 shadow-[0_8px_32px_0_rgba(31,38,135,0.05)] rounded-[20px] transition-all duration-300",
        hoverEffect && "hover:-translate-y-1 hover:shadow-[0_12px_40px_0_rgba(31,38,135,0.1)] cursor-pointer",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
