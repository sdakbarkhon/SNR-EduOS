import { Task } from '../data/tasks';
import { GlassCard } from './GlassCard';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface AssignmentCardProps {
  task: Task;
  onClick: (task: Task) => void;
}

export function AssignmentCard({ task, onClick }: AssignmentCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      <GlassCard 
        hoverEffect 
        onClick={() => onClick(task)}
        className="p-5 flex flex-col sm:flex-row gap-5 items-start sm:items-center justify-between"
      >
        {/* Left Section: Icon & Info */}
        <div className="flex items-start gap-4">
          <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shrink-0", task.iconColorClass)}>
            <task.icon size={28} />
          </div>
          
          <div className="flex flex-col gap-1">
            <h3 className="font-extrabold text-slate-800 text-lg leading-tight">{task.subject}</h3>
            <p className="text-sm font-medium text-slate-500">{task.title}</p>
            {task.status !== 'done' && (
               <p className="text-xs text-slate-400 mt-1 line-clamp-1">{task.description}</p>
            )}
            
            {/* If done, show a snippet of grade/status instead */}
            {task.status === 'done' && task.grade && (
              <div className="flex items-center gap-2 mt-1">
                 <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-md">Оценка: {task.grade}</span>
                 <span className="text-xs text-slate-400">{task.checkDate}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Section: Deadline & Action */}
        <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-3">
           <div className={cn(
             "text-sm font-bold",
             task.deadlineUrgency === 'high' ? 'text-rose-500' :
             task.deadlineUrgency === 'medium' ? 'text-amber-500' : 'text-slate-600'
           )}>
             {task.deadline}
           </div>
           
           <button 
             className="px-6 py-2 bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white rounded-xl font-semibold text-sm transition-all shadow-sm active:scale-95"
           >
             Открыть
           </button>
        </div>
      </GlassCard>
    </motion.div>
  );
}
