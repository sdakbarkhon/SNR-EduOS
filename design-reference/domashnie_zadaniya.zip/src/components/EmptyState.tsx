import { GlassCard } from './GlassCard';

export function EmptyState() {
  return (
    <GlassCard className="flex flex-col items-center justify-center py-20 px-6 text-center">
      <div className="relative w-32 h-32 mb-6 opacity-80">
        {/* Sleeping floating robot mascot */}
        <div className="absolute inset-0 bg-blue-100 rounded-full animate-bounce" style={{ animationDuration: '3s' }}>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-14 bg-gradient-to-tr from-cyan-400 to-blue-500 rounded-2xl">
            {/* Sleeping eyes */}
            <div className="absolute top-4 left-3 w-3 h-1 bg-white rounded-full opacity-60" />
            <div className="absolute top-4 right-3 w-3 h-1 bg-white rounded-full opacity-60" />
            {/* Zzz */}
            <span className="absolute -top-4 -right-4 text-blue-400 font-black text-xl animate-pulse">Z</span>
            <span className="absolute -top-8 -right-8 text-blue-300 font-black text-sm animate-pulse" style={{ animationDelay: '0.2s'}}>z</span>
          </div>
        </div>
      </div>
      <h3 className="text-xl font-bold text-slate-800 mb-2">На сегодня заданий нет, отдыхай!</h3>
      <p className="text-slate-500 text-sm max-w-xs">
        Все активные задачи выполнены. Вы можете посмотреть завершенные задания в соседних вкладках.
      </p>
    </GlassCard>
  );
}
