import { Book, Code, Calculator, Atom, Languages } from "lucide-react";

export type TaskStatus = 'active' | 'review' | 'done' | 'overdue';

export interface Task {
  id: string;
  subject: string;
  title: string;
  deadline: string;
  deadlineUrgency: 'low' | 'medium' | 'high';
  status: TaskStatus;
  icon: any;
  iconColorClass: string;
  description: string;
  attachments?: string[];
  grade?: string;
  teacherComment?: string;
  checkDate?: string;
}

export const mockTasks: Task[] = [
  {
    id: "1",
    subject: "Робототехника",
    title: "Проект 'Умный дом'",
    deadline: "до 16 мая",
    deadlineUrgency: "low",
    status: "active",
    icon: Code,
    iconColorClass: "bg-blue-100 text-blue-600",
    description: "Написать код для контроллера освещения и синхронизировать его с датчиками движения. Подготовить схему подключения.",
    attachments: ["Схема_Умный_Дом.pdf", "Спецификация.docx"]
  },
  {
    id: "2",
    subject: "Информатика",
    title: "Практика в Python",
    deadline: "до 16 мая",
    deadlineUrgency: "low",
    status: "active",
    icon: Code,
    iconColorClass: "bg-blue-100 text-blue-600",
    description: "Разработать алгоритм сортировки массива пузырьком и быстрой сортировки. Сравнить их эффективность."
  },
  {
    id: "3",
    subject: "Математика",
    title: "№224, 250, 236",
    deadline: "до 15 мая",
    deadlineUrgency: "base", // wait, using low/medium/high
    status: "active",
    icon: Calculator,
    iconColorClass: "bg-red-100 text-red-500",
    description: "Решить уравнения из учебника, глава 5."
  },
  {
    id: "4",
    subject: "Физика",
    title: "Лабораторная работа",
    deadline: "до 20 мая",
    deadlineUrgency: "low",
    status: "active",
    icon: Atom,
    iconColorClass: "bg-orange-100 text-orange-500",
    description: "Оформить отчет по лабораторной работе 'Измерение сопротивления проводника'. Подготовить графики."
  },
  {
    id: "5",
    subject: "Английский язык",
    title: "Эссе на тему 'My future'",
    deadline: "до 22 мая",
    deadlineUrgency: "low",
    status: "active",
    icon: Languages,
    iconColorClass: "bg-purple-100 text-purple-600",
    description: "Написать эссе минимум на 150 слов. Использовать Future Perfect и Future Continuous.",
    attachments: ["Requirements.pdf"]
  },
  {
    id: "6",
    subject: "История",
    title: "Конспект параграфа 12",
    deadline: "до 14 мая",
    deadlineUrgency: "medium",
    status: "review",
    icon: Book,
    iconColorClass: "bg-emerald-100 text-emerald-600",
    description: "Сделать краткий конспект основных событий Французской революции."
  },
  {
    id: "7",
    subject: "Литература",
    title: "Анализ стихотворения",
    deadline: "до 12 мая",
    deadlineUrgency: "high",
    status: "overdue",
    icon: Book,
    iconColorClass: "bg-sky-100 text-sky-600",
    description: "Проанализировать стихотворение А.С. Пушкина 'Памятник'. Выделить основные мотивы."
  },
  {
    id: "8",
    subject: "Химия",
    title: "Уравнения реакций",
    deadline: "до 10 мая",
    deadlineUrgency: "low",
    status: "done",
    icon: Atom,
    iconColorClass: "bg-teal-100 text-teal-600",
    description: "Уравнять окислительно-восстановительные реакции методом электронного баланса.",
    grade: "5/5",
    teacherComment: "Отличная работа, все коэффициенты расставлены верно. Молодец!",
    checkDate: "Проверено: 11 мая"
  }
];
