import React, { useState } from 'react';
import { Bell, Shield, BookOpen } from 'lucide-react';
import { mockTasks, Task, TaskStatus } from './data/tasks';
import { FloatingShapes } from './components/FloatingShapes';
import { AssignmentCard } from './components/AssignmentCard';
import { StatsCard } from './components/StatsCard';
import { AdviceCard } from './components/AdviceCard';
import { EmptyState } from './components/EmptyState';
import { TaskModal } from './components/TaskModal';
import { cn } from './lib/utils';
import { AnimatePresence } from 'motion/react';

const TABS: { id: TaskStatus; label: string }[] = [
  { id: 'active', label: 'Активные' },
  { id: 'review', label: 'На проверке' },
  { id: 'done', label: 'Выполненные' },
  { id: 'overdue', label: 'Просроченные' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TaskStatus>('active');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const filteredTasks = mockTasks.filter(t => t.status === activeTab);

  return (
    <div className="min-h-screen font-sans text-slate-800 relative z-0 pb-20">
      <FloatingShapes />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-8 pt-8">
        {/* Header Area */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <h2 className="text-blue-600 font-bold text-sm tracking-widest uppercase mb-1 drop-shadow-sm">Мои задания</h2>
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 bg-blue-600 text-white rounded-[14px] flex items-center justify-center shadow-lg shadow-blue-500/20">
                 <BookOpen size={22} className="stroke-[2.5]" />
               </div>
               <h1 className="text-4xl font-black text-slate-900 tracking-tight drop-shadow-sm">
                 Задания
               </h1>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="w-12 h-12 bg-white/70 backdrop-blur-md border border-white/80 rounded-full flex items-center justify-center text-blue-600 hover:bg-white hover:shadow-md transition-all relative">
              <Bell size={20} />
              <div className="absolute top-3 right-3 w-2 h-2 bg-rose-500 rounded-full border border-white" />
            </button>
            <button className="w-12 h-12 bg-white/70 backdrop-blur-md border border-white/80 rounded-full flex items-center justify-center text-blue-600 hover:bg-white hover:shadow-md transition-all">
               <Shield size={20} />
            </button>
            <button className="flex items-center gap-2 pl-2 pr-4 py-2 bg-white/70 backdrop-blur-md border border-white/80 rounded-full hover:bg-white hover:shadow-md transition-all">
              <img 
                src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=e0f2fe" 
                alt="Avatar" 
                className="w-8 h-8 rounded-full border border-blue-100"
              />
              <span className="font-semibold text-sm mr-1">Иван И.</span>
              <span className="text-slate-400 font-medium text-xs">&gt;</span>
            </button>
          </div>
        </header>

        {/* Tab Switcher */}
        <div className="flex flex-wrap items-center gap-2 mb-8 select-none">
          {TABS.map((tab) => {
            const count = mockTasks.filter(t => t.status === tab.id).length;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "relative px-5 py-2.5 rounded-full font-semibold text-sm transition-all duration-300",
                  isActive 
                    ? "bg-white text-blue-600 shadow-[0_4px_20px_0_rgba(31,38,135,0.05)] scale-105" 
                    : "text-slate-500 hover:text-slate-700 hover:bg-white/40"
                )}
              >
                {/* Active Tab indicator bottom line - visual flair */}
                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-blue-500 rounded-full" />
                )}
                {tab.label} {count > 0 && <span className={cn("ml-1.5 opacity-80 text-xs", isActive ? "text-blue-500" : "text-slate-400")}>({count})</span>}
              </button>
            );
          })}
        </div>

        {/* Main Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column (Assignments List) - 65% visually approx via standard col-span-2 in 3 col grid */}
          <div className="lg:col-span-2 flex flex-col gap-4 min-h-[400px]">
             <AnimatePresence mode="popLayout">
               {filteredTasks.length > 0 ? (
                 filteredTasks.map(task => (
                   <AssignmentCard 
                     key={task.id} 
                     task={task} 
                     onClick={setSelectedTask} 
                   />
                 ))
               ) : (
                 <motion.div
                   initial={{ opacity: 0, scale: 0.9 }}
                   animate={{ opacity: 1, scale: 1 }}
                   exit={{ opacity: 0 }}
                 >
                   <EmptyState />
                 </motion.div>
               )}
             </AnimatePresence>
          </div>

          {/* Right Column (Dashboard Info) */}
          <div className="lg:col-span-1 flex flex-col">
             <StatsCard />
             <AdviceCard />
          </div>

        </div>
      </div>

      {/* Task Detail Modal */}
      <TaskModal task={selectedTask} onClose={() => setSelectedTask(null)} />
    </div>
  );
}
