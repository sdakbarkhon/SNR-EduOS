import { BackgroundShapes } from './components/BackgroundShapes';
import { Calendar } from './components/Calendar';
import { Header } from './components/Header';
import { KPIGrid } from './components/KPIGrid';
import { SubjectProgress } from './components/SubjectProgress';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="min-h-screen relative z-0 text-gray-900 font-sans selection:bg-blue-200">
      <BackgroundShapes />
      
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 pt-6 sm:pt-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          <Header />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut', delay: 0.1 }}
        >
          <KPIGrid />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <motion.div 
            className="lg:col-span-3 h-full"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut', delay: 0.2 }}
          >
            <Calendar />
          </motion.div>
          
          <motion.div 
            className="lg:col-span-2 h-full"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut', delay: 0.3 }}
          >
            <SubjectProgress />
          </motion.div>
        </div>
      </main>
    </div>
  );
}
