import { GlassCard } from './GlassCard';
import { cn } from '../lib/utils';

const DAYS_OF_WEEK = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

// Mock May 2026 data. May 1, 2026 is a Friday.
// So 4 padding days (Mon, Tue, Wed, Thu).
const PADDING_DAYS = Array.from({ length: 4 });

type DayStatus = 'present' | 'absent' | 'holiday' | 'none';

interface CalendarDay {
  day: number;
  status: DayStatus;
  isToday?: boolean;
}

export function Calendar() {
  const days: CalendarDay[] = Array.from({ length: 31 }, (_, i) => {
    const day = i + 1;
    let status: DayStatus = 'present';
    
    // Make weekends holidays
    const dayOfWeek = (4 + day - 1) % 7; // 0=Mon, 4=Fri
    if (dayOfWeek === 5 || dayOfWeek === 6) {
      status = 'holiday';
    } else if (day === 12 || day === 21) {
      status = 'absent';
    } else if (day > 25) {
      status = 'none'; // Future days
    }

    return {
      day,
      status,
      isToday: day === 25,
    };
  });

  return (
    <GlassCard className="p-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900">Календарь посещаемости</h2>
        <div className="flex items-center gap-4 text-xs font-medium text-gray-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            Присутствовал
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-orange-500"></span>
            Отсутствовал
          </div>
        </div>
      </div>

      <div className="flex-1">
        <div className="grid grid-cols-7 gap-y-6 gap-x-2 text-center">
          {/* Header */}
          {DAYS_OF_WEEK.map((d, i) => (
            <div key={d} className={cn("text-sm font-semibold mb-2", i >= 5 ? "text-gray-400" : "text-gray-500")}>
              {d}
            </div>
          ))}

          {/* Padding Slots */}
          {PADDING_DAYS.map((_, i) => (
            <div key={`pad-${i}`} />
          ))}

          {/* Days */}
          {days.map((d) => (
            <div key={d.day} className="flex flex-col items-center justify-start h-12">
              <span 
                className={cn(
                  "w-8 h-8 flex items-center justify-center rounded-full text-sm font-medium transition-all",
                  d.isToday ? "bg-blue-600 text-white shadow-md shadow-blue-500/30" : "text-gray-700",
                  d.status === 'holiday' && !d.isToday ? "text-gray-400" : ""
                )}
              >
                {d.day}
              </span>
              
              {/* Dot Indicator */}
              <div className="mt-1 h-1.5 flex items-center justify-center">
                {d.status === 'present' && <span className="w-1.5 h-1.5 rounded-full bg-green-500" />}
                {d.status === 'absent' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500/50" />}
              </div>
            </div>
          ))}
        </div>
      </div>
    </GlassCard>
  );
}
