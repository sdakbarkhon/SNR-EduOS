import { GlassCard } from './GlassCard';
import { cn } from '../lib/utils';

interface KPIProps {
  label: string;
  value: string;
  valueColor: string;
}

export function KPIGrid() {
  const kpis: KPIProps[] = [
    { label: 'Общая посещаемость', value: '95%', valueColor: 'text-green-600' },
    { label: 'Дней без пропусков', value: '18 дней', valueColor: 'text-blue-600' },
    { label: 'Пропущено занятий', value: '2 урока', valueColor: 'text-orange-500' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {kpis.map((kpi, idx) => (
        <GlassCard key={idx} className="p-6 flex flex-col gap-2 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-white/40 blur-2xl rounded-full translate-x-12 -translate-y-12 group-hover:scale-110 transition-transform duration-500"/>
          
          <span className="text-sm font-medium text-gray-500 relative z-10">{kpi.label}</span>
          <span className={cn("text-3xl xl:text-4xl font-bold relative z-10", kpi.valueColor)}>
            {kpi.value}
          </span>
        </GlassCard>
      ))}
    </div>
  );
}
