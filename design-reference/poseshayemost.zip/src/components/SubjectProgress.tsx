import { BookOpen, Calculator, Cpu, Monitor } from 'lucide-react';
import { GlassCard } from './GlassCard';

interface SubjectProps {
  name: string;
  percent: number;
  icon: React.ReactNode;
  colorClass: string;
}

export function SubjectProgress() {
  const subjects: SubjectProps[] = [
    {
      name: 'Робототехника',
      percent: 100,
      icon: <Cpu className="w-5 h-5 text-purple-600" />,
      colorClass: 'bg-purple-500',
    },
    {
      name: 'Математика',
      percent: 90,
      icon: <Calculator className="w-5 h-5 text-blue-600" />,
      colorClass: 'bg-blue-500',
    },
    {
      name: 'Информатика',
      percent: 85,
      icon: <Monitor className="w-5 h-5 text-orange-500" />,
      colorClass: 'bg-orange-500',
    },
    {
      name: 'Английский язык',
      percent: 100,
      icon: <BookOpen className="w-5 h-5 text-green-600" />,
      colorClass: 'bg-green-500',
    },
  ];

  return (
    <GlassCard className="p-6 h-full flex flex-col">
      <h2 className="text-xl font-bold text-gray-900 mb-6">По предметам</h2>
      
      <div className="flex-1 flex flex-col gap-6">
        {subjects.map((subject, idx) => (
          <div key={idx} className="group">
            <div className="flex justify-between items-center mb-2.5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/60 flex items-center justify-center shadow-sm border border-white/50 group-hover:scale-105 transition-transform">
                  {subject.icon}
                </div>
                <span className="font-semibold text-gray-800">{subject.name}</span>
              </div>
              <span className="font-bold text-gray-900">{subject.percent}%</span>
            </div>
            
            <div className="h-2.5 w-full bg-black/[0.04] rounded-full overflow-hidden shadow-inner">
              <div 
                className={`h-full ${subject.colorClass} rounded-full transition-all duration-1000 ease-out`} 
                style={{ width: `${subject.percent}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
