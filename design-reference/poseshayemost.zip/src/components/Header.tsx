import { Bell, ChevronLeft, ChevronRight, User } from 'lucide-react';
import { GlassCard } from './GlassCard';

export function Header() {
  return (
    <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
      <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
        Посещаемость
      </h1>
      
      <div className="flex items-center gap-4">
        {/* Month Selector */}
        <GlassCard className="flex items-center gap-4 px-4 py-2.5">
          <button className="text-gray-500 hover:text-gray-900 transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="font-semibold text-gray-800 text-sm md:text-base w-24 text-center">
            Май 2026
          </span>
          <button className="text-gray-500 hover:text-gray-900 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </button>
        </GlassCard>

        {/* Notifications */}
        <GlassCard className="p-2.5 flex items-center justify-center cursor-pointer hover:bg-white/80 transition-colors">
          <div className="relative">
            <Bell className="w-5 h-5 text-gray-700" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
          </div>
        </GlassCard>

        {/* User Profile */}
        <GlassCard className="p-1 cursor-pointer hover:bg-white/80 transition-colors">
          <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
            <User className="w-5 h-5" />
          </div>
        </GlassCard>
      </div>
    </header>
  );
}
