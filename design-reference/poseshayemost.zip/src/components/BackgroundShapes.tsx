import { motion } from 'motion/react';

export function BackgroundShapes() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-gradient-to-br from-[#E0F2FE] via-[#E8F0FE] to-[#F3E8FF]">
      <motion.div
        className="absolute top-[5%] left-[15%] w-80 h-80 bg-cyan-300/40 rounded-full blur-[80px] mix-blend-multiply"
        animate={{ y: [0, 30, 0], x: [0, -20, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute top-[30%] right-[10%] w-[400px] h-[400px] bg-purple-300/40 rounded-full blur-[100px] mix-blend-multiply"
        animate={{ y: [0, -40, 0], x: [0, 40, 0] }}
        transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-[5%] left-[30%] w-[350px] h-[350px] bg-blue-300/30 rounded-full blur-[90px] mix-blend-multiply"
        animate={{ y: [0, 40, 0], scale: [1, 1.05, 1] }}
        transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
      />
      
      {/* Additional subtle shapes for depth */}
      <motion.div
        className="absolute top-[60%] right-[40%] w-64 h-64 bg-emerald-200/20 rounded-full blur-[60px] mix-blend-overlay"
        animate={{ rotate: 360, scale: [1, 1.2, 1] }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
      />
    </div>
  );
}
